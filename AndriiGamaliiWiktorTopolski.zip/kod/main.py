from experiments import compare_models
from experiments import print_out_results

def main():
    compare_models()
    print_out_results()
    pass



if __name__ == "__main__":
    main()
